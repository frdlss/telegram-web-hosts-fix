@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul 2>&1
cd /d "%~dp0"
title Telegram Web Fix
set "HOSTS=%SystemRoot%\System32\drivers\etc\hosts"
set "MARKER=# zapret-telegram-web-fix"
set "CFG=%~dp0telegram-web-ip.cfg"
set "PS_DETECT=%~dp0utils\telegram-autodetect.ps1"
set "PS_HOSTS=%~dp0utils\tg-hosts.ps1"
set "DOMAINS=%~dp0lists\telegram-hosts-domains.txt"
set "BACKUP=%~dp0backup"
if /i "%~1"=="enable-silent" goto :enable_cli
if /i "%~1"=="disable-silent" goto :disable_cli
if /i "%~1"=="__run" (
    shift /1
    goto :bootstrap
)
net session >nul 2>&1
if %errorlevel% equ 0 goto :bootstrap
cls
echo.
echo   Telegram Web Fix
echo   Подтвердите окно UAC - нажмите "Да"
echo.
powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -ArgumentList '__run' -WorkingDirectory '%~dp0' -Verb RunAs"
exit /b 0
:bootstrap
@echo off
chcp 65001 >nul 2>&1
cls
mode con: cols=76 lines=40 >nul 2>&1
call :init_esc
call :load_ip
goto :menu
:enable_cli
net session >nul 2>&1
if %errorlevel% neq 0 exit /b 1
call :require_cfg
if errorlevel 1 exit /b 2
call :apply_hosts
exit /b %errorlevel%
:disable_cli
net session >nul 2>&1
if %errorlevel% neq 0 exit /b 1
call :disable_hosts_silent
if "!DH_OK!"=="0" (
    ipconfig /flushdns >nul
    exit /b 0
)
exit /b 1
:init_esc
set "ESC="
for /F "tokens=1,2 delims=#" %%a in ('"prompt #$H#$E# & echo on & for %%b in (1) do rem"') do set "ESC=%%b"
if not defined ESC (
    set "R=" & set "GRN=" & set "RED=" & set "YLW=" & set "GRY=" & set "CYN=" & set "WHT=" & set "DIM="
    exit /b 0
)
set "R=!ESC![0m"
set "GRN=!ESC![92m"
set "RED=!ESC![91m"
set "YLW=!ESC![93m"
set "GRY=!ESC![90m"
set "CYN=!ESC![96m"
set "WHT=!ESC![97m"
set "DIM=!ESC![2m"
exit /b 0
:run_ps_hidden
set "PS_RUNBAT=%TEMP%\telegram-web-fix-ps-run.bat"
> "%PS_RUNBAT%" echo @echo off
>>"%PS_RUNBAT%" echo !PS_CMD!
>>"%PS_RUNBAT%" echo exit /b %%ERRORLEVEL%%
start "" /wait /min cmd /c "%PS_RUNBAT%"
set "PS_EXIT=!errorlevel!"
del "%PS_RUNBAT%" 2>nul
exit /b 0
:load_ip
set "TG_IP="
if not exist "%CFG%" exit /b 0
for /f "usebackq tokens=*" %%a in (`findstr /R /C:"[0-9][0-9]*\.[0-9][0-9]*\.[0-9][0-9]*\.[0-9][0-9]*" "%CFG%" 2^>nul`) do set "TG_IP=%%a"
exit /b 0
:require_cfg
call :load_ip
if not exist "%CFG%" exit /b 1
if not defined TG_IP exit /b 1
exit /b 0
:apply_hosts
if not exist "%PS_HOSTS%" exit /b 1
if not exist "%DOMAINS%" exit /b 1
set "PS_CMD=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PS_HOSTS%" -Action Apply -Ip "%TG_IP%" -DomainsFile "%DOMAINS%" -BackupDir "%BACKUP%""
call :run_ps_hidden
if not "!PS_EXIT!"=="0" exit /b 1
ipconfig /flushdns >nul
exit /b 0
:disable_hosts_silent
set "DH_OK=1"
if not exist "%PS_HOSTS%" exit /b 1
set "PS_CMD=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PS_HOSTS%" -Action Remove -DomainsFile "%DOMAINS%""
call :run_ps_hidden
if not "!PS_EXIT!"=="0" exit /b 1
set "PS_CMD=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PS_HOSTS%" -Action Verify -DomainsFile "%DOMAINS%""
call :run_ps_hidden
if not "!PS_EXIT!"=="0" exit /b 1
set "DH_OK=0"
exit /b 0
:header
cls
call :init_esc
call :draw_main
exit /b 0
:draw_main
echo.
echo   !CYN!╔════════════════════════════════════════════════════════════════════════╗!R!
echo   !CYN!║!R!                            !GRN!TELEGRAM WEB FIX!R!                            !CYN!║!R!
echo   !CYN!║!R!                      !DIM!web.telegram.org через hosts!R!                      !CYN!║!R!
echo   !CYN!╚════════════════════════════════════════════════════════════════════════╝!R!
echo.
call :status_line
call :menu_body
exit /b 0
:status_line
findstr /C:"%MARKER%" "%HOSTS%" >nul 2>&1
if not errorlevel 1 goto :st_fix_on
set "FIX_T=!YLW!выкл!R!"
goto :st_fix_done
:st_fix_on
set "FIX_T=!GRN!вкл!R!"
:st_fix_done
call :box_top "Состояние"
echo   !GRY!│!R!  Фикс ............. !FIX_T!
echo   !GRY!│!R!  !DIM!hosts сохраняется после перезагрузки ПК (пока не [2])!R!
if defined TG_IP goto :st_has_ip
echo   !GRY!│!R!  IP ............... !GRY!не задан!R!
echo   !GRY!│!R!  Конфиг ........... !GRY!сначала [4]!R!
goto :st_after_ip
:st_has_ip
echo   !GRY!│!R!  IP ............... !CYN! !TG_IP! !R!
echo   !GRY!│!R!  Конфиг ........... !WHT!telegram-web-ip.cfg!R!
:st_after_ip
echo   !GRY!│!R!  Домены ........... !DIM!Web + WebSocket (QR)!R!
call :box_bottom
echo.
exit /b 0
:menu_body
call :box_top "Меню"
echo   !GRY!│!R!
if defined TG_IP goto :mn_item1_ok
echo   !GRY!│!R!   !GRY![1]!R!  !GRY!Включить!R!       !DIM!сначала [4]!R!
goto :mn_after1
:mn_item1_ok
echo   !GRY!│!R!   !GRN![1]!R!  !WHT!Включить!R!       !DIM!- записать fix в hosts!R!
:mn_after1
echo   !GRY!│!R!   !RED![2]!R!  !WHT!Выключить!R!      !DIM!- убрать все строки!R!
echo   !GRY!│!R!   !CYN![3]!R!  !WHT!Просмотр!R!       !DIM!- строки в hosts!R!
echo   !GRY!│!R!   !GRN![4]!R!  !WHT!Поиск IP!R!       !DIM!- найти рабочий IP!R!
echo   !GRY!│!R!   !GRY![0]!R!  !WHT!Выход!R!
echo   !GRY!│!R!
if defined TG_IP goto :mn_hint_ok
echo   !GRY!│!R!   !YLW!Сначала [4] Поиск IP, потом [1] Включить!R!
goto :mn_hint_done
:mn_hint_ok
echo   !GRY!│!R!   !GRY!Дальше: [1] Включить!R!
echo   !GRY!│!R!   !DIM![1] сохраняется после перезагрузки ПК, пока не [2]!R!
:mn_hint_done
call :box_bottom
echo.
exit /b 0
:box_top
echo   !GRY!┌────────────────────────────────────────────────────────────────────────┐!R!
echo   !GRY!│!R!  !WHT!%~1!R!
echo   !GRY!├────────────────────────────────────────────────────────────────────────┤!R!
exit /b 0
:box_bottom
echo   !GRY!└────────────────────────────────────────────────────────────────────────┘!R!
exit /b 0
:section
echo.
call :box_top "%~1"
exit /b 0
:wait
call :box_bottom
echo.
echo   !DIM!  Любая клавиша - в меню...!R!
pause >nul
echo.
exit /b 0
:line_ok
echo   !GRY!│!R!   !GRN![OK]!R!  %~1
exit /b 0
:line_fail
echo   !GRY!│!R!   !RED![!!]!R!  %~1
exit /b 0
:line_info
echo   !GRY!│!R!   !GRY![i]!R!   %~1
exit /b 0
:banner_ok
echo   !GRY!│!R!
echo   !GRY!│!R!   !GRN!^>^> %~1!R!
echo   !GRY!│!R!
exit /b 0
:banner_fail
echo   !GRY!│!R!
echo   !GRY!│!R!   !RED!^>^> %~1!R!
echo   !GRY!│!R!
exit /b 0
:scan_show_log
for /f "usebackq tokens=1,2,3 delims=|" %%a in ("%~1") do call :scan_line "%%a" "%%b" "%%c"
exit /b 0
:scan_line
if "%~1"=="DNS" (
    echo   !YLW!DNS: web.telegram.org -^> %~2!R!
    echo   !DIM!часто недоступен у провайдера, ищем другой...!R!
    exit /b 0
)
if "%~1"=="NODNS" (
    echo   !YLW!DNS не ответил - идём по списку кандидатов!R!
    exit /b 0
)
if "%~1"=="COUNT" (
    echo   !WHT!Тестируем %~2 адресов...!R!
    echo.
    exit /b 0
)
if "%~1"=="ROW" (
    if /i "%~3"=="skip" (
        echo   %~2    !DIM!пропуск (DNS^)!R!
    ) else if /i "%~3"=="ok" (
        echo   %~2    !GRN!доступен!R!
    ) else (
        echo   %~2    !RED!нет!R!
    )
    exit /b 0
)
if "%~1"=="ERR" (
    if "%~2"=="empty_list" echo   !RED!Список пуст: lists\telegram-ip-candidates.txt!R!
    if "%~2"=="no_reply" echo   !RED!Ни один IP не ответил. Добавьте адреса в lists\telegram-ip-candidates.txt!R!
    exit /b 0
)
exit /b 0
:menu
call :load_ip
call :init_esc
call :header
set "choice="
set /p "choice=  Выбор: > "
if not defined choice goto :menu
set "choice=!choice: =!"
if "!choice!"=="1" goto :enable
if "!choice!"=="2" goto :disable
if "!choice!"=="3" goto :show
if "!choice!"=="4" goto :autodetect
if "!choice!"=="0" goto :bye
goto :menu
:autodetect
cls
call :init_esc
call :section "Поиск IP"
if not exist "%PS_DETECT%" (
    call :line_fail "Нет utils\telegram-autodetect.ps1"
    call :wait
    goto :menu
)
call :line_info "Список: lists\telegram-ip-candidates.txt"
call :box_bottom
echo.
echo   !CYN!Проверка адресов Telegram (порт 443)...!R!
echo   !DIM!Подождите, идёт проверка...!R!
echo.
set "SCAN_LOG=%TEMP%\telegram-web-fix-scan.log"
del "%SCAN_LOG%" 2>nul
set "PS_CMD=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PS_DETECT%" -LogFile "%SCAN_LOG%""
call :run_ps_hidden
set "DETECT_OK=!PS_EXIT!"
if exist "%SCAN_LOG%" call :scan_show_log "%SCAN_LOG%"
call :load_ip
echo.
if not "!DETECT_OK!"=="0" (
    echo   !RED!^>^> IP не найден!R!
) else (
    echo   !GRN!Сохранено: telegram-web-ip.cfg!R!
    echo   !GRN!IP для hosts: !TG_IP!!R!
    echo.
    echo   !GRN!^>^> Готово: !TG_IP! - нажмите [1]!R!
)
echo.
echo   !DIM!  Любая клавиша - в меню...!R!
pause >nul
goto :menu
:enable
call :require_cfg
if errorlevel 1 (
    call :header
    call :section "Включение"
    call :line_fail "Сначала [4] Поиск IP"
    call :wait
    goto :menu
)
call :header
call :section "Включение"
if not exist "%PS_HOSTS%" (
    call :line_fail "Нет utils\tg-hosts.ps1"
    call :wait
    goto :menu
)
call :apply_hosts
if not "!PS_EXIT!"=="0" (
    call :line_fail "Не удалось записать hosts (код !PS_EXIT!)"
    call :line_info "Запуск от имени администратора обязателен"
    call :wait
    goto :menu
)
call :line_ok "hosts обновлен"
call :line_ok "DNS сброшен"
call :banner_ok "Включено - откройте web.telegram.org"
call :wait
goto :menu
:disable
call :header
call :section "Выключение"
call :disable_hosts_silent
if "!DH_OK!"=="0" (
    call :line_ok "Записи удалены"
    ipconfig /flushdns >nul
    call :line_ok "DNS сброшен"
    findstr /C:"%MARKER%" "%HOSTS%" >nul 2>&1
    if not errorlevel 1 (
        call :banner_fail "В hosts остались строки"
    ) else (
        call :banner_ok "Выключено"
    )
) else (
    call :line_fail "Нет доступа к hosts"
)
call :wait
goto :menu
:show
call :init_esc
call :header
call :section "Файл hosts"
set "found=0"
for /f "tokens=*" %%L in ('findstr /I "telegram" "%HOSTS%" 2^>nul') do (
    echo   !GRY!|!R!   !DIM!%%L!R!
    set "found=1"
)
if "!found!"=="0" (
    call :line_info "Строк Telegram в hosts пока нет"
    call :line_info "Это нормально, если fix еще не включали"
    call :line_info "Сначала [4] Поиск IP, затем [1] Включить"
)
call :wait
goto :menu
:bye
call :header
echo     !GRY!Пока.!R!
echo.
timeout /t 1 >nul
exit /b 0