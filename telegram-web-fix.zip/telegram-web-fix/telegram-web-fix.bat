@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul 2>&1
cd /d "%~dp0"
title Telegram Web Fix
set "HOSTS=%SystemRoot%\System32\drivers\etc\hosts"
set "MARKER=# zapret-telegram-web-fix"
set "CFG=%~dp0telegram-web-ip.cfg"
set "PS_DETECT=%~dp0utils\telegram-autodetect.ps1"
set "PS_HOSTS=%~dp0utils\tg-hosts.ps1"
set "DOMAINS=%~dp0lists\telegram-hosts-domains.txt"
set "BACKUP=%~dp0backup"
if /i "%~1"=="enable-silent" goto :enable_cli
if /i "%~1"=="disable-silent" goto :disable_cli
if /i "%~1"=="__run" (
    shift /1
    goto :bootstrap
)
net session >nul 2>&1
if %errorlevel% equ 0 goto :bootstrap
cls
echo.
echo   Telegram Web Fix
echo   Подтвердите UAC - нажмите "Да"
echo.
echo   Это окно закроется. Основное откроется отдельно - смотрите панель задач.
echo.
powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -ArgumentList '__run' -WorkingDirectory '%~dp0' -Verb RunAs"
timeout /t 2 >nul
exit /b 0
:bootstrap
@echo off
chcp 65001 >nul 2>&1
cls
mode con: cols=76 lines=40 >nul 2>&1
call :init_esc
call :load_ip
goto :menu
:enable_cli
net session >nul 2>&1
if %errorlevel% neq 0 exit /b 1
call :require_cfg
if errorlevel 1 exit /b 2
call :apply_hosts
exit /b %errorlevel%
:disable_cli
net session >nul 2>&1
if %errorlevel% neq 0 exit /b 1
call :disable_hosts_silent
if "!DH_OK!"=="0" (
    ipconfig /flushdns >nul
    exit /b 0
)
exit /b 1
:run_ps_hidden
set "PS_LAUNCH=!PS_CMD!"
set "PS_LAUNCH=!PS_LAUNCH:powershell.exe=powershell.exe -WindowStyle Hidden!"
start "" /wait !PS_LAUNCH!
set "PS_EXIT=!errorlevel!"
exit /b 0
:init_esc
set "ESC="
for /F "tokens=1,2 delims=#" %%a in ('"prompt #$H#$E# & echo on & for %%b in (1) do rem"') do set "ESC=%%b"
if not defined ESC (
    set "R=" & set "GRN=" & set "RED=" & set "YLW=" & set "GRY=" & set "CYN=" & set "WHT=" & set "DIM="
    exit /b 0
)
set "R=!ESC![0m"
set "GRN=!ESC![92m"
set "RED=!ESC![91m"
set "YLW=!ESC![93m"
set "GRY=!ESC![90m"
set "CYN=!ESC![96m"
set "WHT=!ESC![97m"
set "DIM=!ESC![2m"
exit /b 0
:load_ip
set "TG_IP="
if not exist "%CFG%" exit /b 0
for /f "usebackq tokens=*" %%a in (`findstr /R /C:"[0-9][0-9]*\.[0-9][0-9]*\.[0-9][0-9]*\.[0-9][0-9]*" "%CFG%" 2^>nul`) do set "TG_IP=%%a"
exit /b 0
:require_cfg
call :load_ip
if not exist "%CFG%" exit /b 1
if not defined TG_IP exit /b 1
exit /b 0
:apply_hosts
if not exist "%PS_HOSTS%" exit /b 1
if not exist "%DOMAINS%" exit /b 1
set "PS_CMD=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PS_HOSTS%" -Action Apply -Ip "%TG_IP%" -DomainsFile "%DOMAINS%" -BackupDir "%BACKUP%""
call :run_ps_hidden
if not "!PS_EXIT!"=="0" exit /b 1
ipconfig /flushdns >nul
exit /b 0
:disable_hosts_silent
set "DH_OK=1"
if not exist "%PS_HOSTS%" exit /b 1
set "PS_CMD=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PS_HOSTS%" -Action Remove -DomainsFile "%DOMAINS%""
call :run_ps_hidden
if not "!PS_EXIT!"=="0" exit /b 1
set "PS_CMD=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PS_HOSTS%" -Action Verify -DomainsFile "%DOMAINS%""
call :run_ps_hidden
if not "!PS_EXIT!"=="0" exit /b 1
set "DH_OK=0"
exit /b 0
:header
cls
call :init_esc
call :draw_main
exit /b 0
:draw_main
echo.
echo   !CYN!╔════════════════════════════════════════════════════════════════════════╗!R!
echo   !CYN!║!R!                            !GRN!TELEGRAM WEB FIX!R!                            !CYN!║!R!
echo   !CYN!║!R!                      !DIM!web.telegram.org через hosts!R!                      !CYN!║!R!
echo   !CYN!╚════════════════════════════════════════════════════════════════════════╝!R!
echo.
call :status_line
call :menu_body
exit /b 0
:status_line
findstr /C:"%MARKER%" "%HOSTS%" >nul 2>&1
if not errorlevel 1 goto :st_fix_on
set "FIX_T=!YLW!выкл!R!"
goto :st_fix_done
:st_fix_on
set "FIX_T=!GRN!вкл!R!"
:st_fix_done
call :box_top "Состояние"
echo   !GRY!│!R!  Фикс ............... !FIX_T!
echo   !GRY!│!R!  !DIM!hosts сохраняется после перезагрузки ПК (пока не [2])!R!
if defined TG_IP goto :st_has_ip
echo   !GRY!│!R!  IP ................ !GRY!не задан!R!
echo   !GRY!│!R!  Конфиг ............ !GRY!сначала [4]!R!
goto :st_after_ip
:st_has_ip
echo   !GRY!│!R!  IP ................ !CYN! !TG_IP! !R!
echo   !GRY!│!R!  Конфиг ............ !WHT!telegram-web-ip.cfg!R!
:st_after_ip
echo   !GRY!│!R!  Домены ............ !DIM!Web + WebSocket (QR)!R!
call :box_bottom
echo.
exit /b 0
:menu_body
call :box_top "Меню"
echo   !GRY!│!R!
if defined TG_IP goto :mn_item1_ok
echo   !GRY!│!R!   !GRY![1]!R!  !GRY!Включить!R!        !DIM!сначала [4]!R!
goto :mn_after1
:mn_item1_ok
echo   !GRY!│!R!   !GRN![1]!R!  !WHT!Включить!R!        !DIM!- записать fix в hosts!R!
:mn_after1
echo   !GRY!│!R!   !RED![2]!R!  !WHT!Выключить!R!       !DIM!- убрать наши строки!R!
echo   !GRY!│!R!   !CYN![3]!R!  !WHT!Просмотр!R!       !DIM!- строки в hosts!R!
echo   !GRY!│!R!   !GRN![4]!R!  !WHT!Поиск IP!R!       !DIM!- проверка DC :443!R!
echo   !GRY!│!R!   !GRY![0]!R!  !WHT!Выход!R!
echo   !GRY!│!R!
if defined TG_IP goto :mn_hint_ok
echo   !GRY!│!R!   !YLW!Сначала [4] Поиск IP, потом [1] Включить!R!
goto :mn_hint_done
:mn_hint_ok
echo   !GRY!│!R!   !GRY!Дальше: [1] Включить!R!
echo   !GRY!│!R!   !DIM![1] сохраняется после перезагрузки, пока не [2]!R!
:mn_hint_done
call :box_bottom
echo.
exit /b 0
:box_top
echo   !GRY!┌────────────────────────────────────────────────────────────────────────┐!R!
echo   !GRY!│!R!  !WHT!%~1!R!
echo   !GRY!├────────────────────────────────────────────────────────────────────────┤!R!
exit /b 0
:box_bottom
echo   !GRY!└────────────────────────────────────────────────────────────────────────┘!R!
exit /b 0
:section
echo.
call :box_top "%~1"
exit /b 0
:wait
call :box_bottom
echo.
echo   !DIM!  Любая клавиша — в меню...!R!
pause >nul
echo.
exit /b 0
:line_ok
echo   !GRY!│!R!   !GRN![OK]!R!  %~1
exit /b 0
:line_fail
echo   !GRY!│!R!   !RED![!!]!R!  %~1
exit /b 0
:line_info
echo   !GRY!│!R!   !GRY![i]!R!   %~1
exit /b 0
:banner_ok
echo   !GRY!│!R!
echo   !GRY!│!R!   !GRN!^>^> %~1!R!
echo   !GRY!│!R!
exit /b 0
:banner_fail
echo   !GRY!│!R!
echo   !GRY!│!R!   !RED!^>^> %~1!R!
echo   !GRY!│!R!
exit /b 0
:scan_show_log
set "RPT_DNS=0"
set "RPT_SITES=0"
for /f "usebackq tokens=1,2,3 delims=|" %%a in ("%~1") do call :scan_line "%%a" "%%b" "%%c"
if "!RPT_DNS!"=="0" echo   !GRY!  DNS ................... нет данных!R!
exit /b 0
:scan_line
if "%~1"=="DR" call :scan_dr "%~2" "%~3"
if "%~1"=="DR" exit /b 0
if "%~1"=="DS" call :scan_ds "%~2" "%~3"
if "%~1"=="DS" exit /b 0
if "%~1"=="DSN" echo   !GRY!  ... плюс %~2 доменов в очереди!R!
if "%~1"=="DSN" exit /b 0
if "%~1"=="Q" if not defined RPT_Q echo   !GRY!  В очереди .............. %~2 IP, параллельно %~3!R!
if "%~1"=="Q" set "RPT_Q=1"
if "%~1"=="Q" exit /b 0
if "%~1"=="MS" if not defined RPT_MS echo   !GRY!  Таймаут TCP ........... %~2 мс!R!
if "%~1"=="MS" set "RPT_MS=1"
if "%~1"=="MS" exit /b 0
if "%~1"=="PROG" call :scan_live_prog "%~2" "%~3"
if "%~1"=="PROG" exit /b 0
if "%~1"=="LIVE" if /i "%~2"=="ok" echo   !GRN!  ^>^> Открыт: %~3!R!
if "%~1"=="LIVE" if /i "%~2"=="ok2" echo   !GRN!  ^>^> Открыт (TNC): %~3!R!
if "%~1"=="LIVE" exit /b 0
if "%~1"=="ADDED" echo   !DIM!  В lists/telegram-ip-candidates.txt добавлено: %~2 IP!R!
if "%~1"=="ADDED" exit /b 0
if "%~1"=="DONE" exit /b 0
if "%~1"=="MSG" if not "%~2"=="" if defined TG_SCAN_VERBOSE_LOG call :scan_echo_dim "%~2"
if "%~1"=="MSG" exit /b 0
if "%~1"=="DNS" if not defined RPT_DNS_IP echo   !YLW!  web.telegram.org ...... %~2  !DIM!(часто не открывается^)!R!
if "%~1"=="DNS" set "RPT_DNS_IP=1"
if "%~1"=="DNS" exit /b 0
if "%~1"=="NODNS" if not defined RPT_DNS_IP echo   !YLW!  web.telegram.org ...... DNS не ответил!R!
if "%~1"=="NODNS" set "RPT_DNS_IP=1"
if "%~1"=="NODNS" exit /b 0
if "%~1"=="COUNT" if not defined RPT_Q echo   !GRY!  В очереди .............. %~2 IP!R!
if "%~1"=="COUNT" set "RPT_Q=1"
if "%~1"=="COUNT" exit /b 0
if "%~1"=="PASS2" echo   !YLW!  Повторная проверка .... Test-NetConnection!R!
if "%~1"=="PASS2" exit /b 0
if "%~1"=="N" if "%~2"=="diag" echo   !CYN!  --- если IP не найден ---!R!
if "%~1"=="N" if "%~2"=="cand" echo   !GRY!    в очереди: %~3!R!
if "%~1"=="N" if "%~2"=="file" echo   !GRY!    из файла: %~3!R!
if "%~1"=="N" if "%~2"=="dnsA" echo   !GRY!    DNS-записей: %~3!R!
if "%~1"=="N" if "%~2"=="dnsSrv" echo   !GRY!    DNS с ответом: %~3 из 4!R!
if "%~1"=="N" if "%~2"=="tcpTry" echo   !GRY!    проверок TCP: %~3!R!
if "%~1"=="N" if "%~2"=="tncTry" echo   !GRY!    проверок TNC: %~3!R!
if "%~1"=="N" exit /b 0
if "%~1"=="ROW" exit /b 0
if "%~1"=="ERR" if "%~2"=="empty_list" echo   !RED!  Список пуст: lists\telegram-ip-candidates.txt!R!
if "%~1"=="ERR" if "%~2"=="no_reply" call :scan_err_no_reply
if "%~1"=="ERR" exit /b 0
if "%~1"=="FOUND" echo   !GRN!  Сохранён в telegram-web-ip.cfg: %~2!R!
if "%~1"=="FOUND" set "RPT_FOUND=%~2"
if "%~1"=="FOUND" exit /b 0
exit /b 0
:scan_dr
set "RPT_DNS=1"
if /i "%~2"=="ok" echo   !GRY!  DNS %~1  !GRN!A-запись!R!
if /i "%~2"=="empty" echo   !GRY!  DNS %~1  !YLW!нет A!R!
if /i "%~2"=="timeout" echo   !GRY!  DNS %~1  !YLW!таймаут!R!
exit /b 0
:scan_ds
set /a RPT_SITES+=1
if "%~3"=="-" echo   !GRY!  %~2  —!R!
if not "%~3"=="-" echo   !GRY!  %~2  %~3!R!
exit /b 0
:scan_echo_dim
set "SCAN_T=%~1"
set "SCAN_T=!SCAN_T:>=^>!"
set "SCAN_T=!SCAN_T:<=^<!"
set "SCAN_T=!SCAN_T:&=^&!"
set "SCAN_T=!SCAN_T:|=^|!"
echo   !DIM!    !SCAN_T!!R!
exit /b 0
:scan_err_no_reply
echo   !RED!  Ни один IP не ответил на TCP 443.!R!
echo   !GRY!  Попробуйте другую сеть или VPN.!R!
echo   !GRY!  Подсети: !R!!CYN!https://core.telegram.org/resources/cidr.txt!R!
exit /b 0
:scan_live_prog
if "!SCAN_PROG2!"=="%~1" exit /b 0
set "SCAN_PROG2=%~1"
echo   !GRY!  TCP :443 .............. [!%~1!/!%~2!]!R!
exit /b 0
:menu
call :load_ip
call :init_esc
call :header
set "choice="
set /p "choice=  Выбор: > "
if not defined choice goto :menu
set "choice=!choice: =!"
if "!choice!"=="1" goto :enable
if "!choice!"=="2" goto :disable
if "!choice!"=="3" goto :show
if "!choice!"=="4" goto :autodetect
if "!choice!"=="0" goto :bye
goto :menu
:autodetect
cls
call :init_esc
call :section "Поиск IP"
if not exist "%PS_DETECT%" goto :ad_no_detect
call :line_info "Список: lists\telegram-ip-candidates.txt"
call :box_bottom
echo.
echo   !CYN!Проверка адресов Telegram (TCP 443^)...!R!
echo   !DIM!Подождите, идёт скан (обычно 1-3 мин^)...!R!
echo.
set "SCAN_LOG=%TEMP%\telegram-web-fix-scan.log"
del "%SCAN_LOG%" 2>nul
set "PS_CMD=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PS_DETECT%" -LogFile "%SCAN_LOG%""
call :run_ps_hidden
set "DETECT_OK=!PS_EXIT!"
call :load_ip
echo.
if exist "%SCAN_LOG%" (
    echo   !GRY!├────────────────────────────────────────────────────────────────────────┤!R!
    echo   !GRY!│!R!  !WHT!Отчёт!R!
    echo   !GRY!├────────────────────────────────────────────────────────────────────────┤!R!
    call :scan_show_log "%SCAN_LOG%"
    echo   !GRY!└────────────────────────────────────────────────────────────────────────┘!R!
) else (
    echo   !RED!Скан не записал лог — %TEMP%!R!
)
echo.
if defined TG_IP echo   !GRN!^>^>^> Рабочий IP: !TG_IP!!R!
if not defined TG_IP if not "!DETECT_OK!"=="0" echo   !RED!^>^> IP не найден!R!
if not defined TG_IP if not "!DETECT_OK!"=="0" if not exist "%SCAN_LOG%" echo   !RED!Скан не записал лог — %TEMP%!R!
if defined TG_IP echo   !GRN!Дальше: [1] Включить  —  web.telegram.org!R!
echo.
echo   !DIM!  Любая клавиша — в меню...!R!
pause >nul
goto :menu
:ad_no_detect
call :line_fail "Нет utils\telegram-autodetect.ps1"
call :wait
goto :menu
:enable
call :require_cfg
if errorlevel 1 goto :en_no_cfg
call :header
call :section "Включение"
if not exist "%PS_HOSTS%" goto :en_no_hosts
call :apply_hosts
if errorlevel 1 goto :en_apply_fail
call :line_ok "hosts обновлен"
call :line_ok "DNS сброшен"
call :banner_ok "Включено - откройте web.telegram.org"
call :wait
goto :menu
:en_no_cfg
call :header
call :section "Включение"
call :line_fail "Сначала [4] Поиск IP"
call :wait
goto :menu
:en_no_hosts
call :line_fail "Нет utils\tg-hosts.ps1"
call :wait
goto :menu
:en_apply_fail
call :line_fail "Не удалось записать hosts (код !PS_EXIT!)"
call :line_info "Нужен запуск от имени администратора"
call :wait
goto :menu
:disable
call :header
call :section "Выключение"
call :disable_hosts_silent
if "!DH_OK!"=="0" (
    call :line_ok "Записи удалены"
    ipconfig /flushdns >nul
    call :line_ok "DNS сброшен"
    findstr /C:"%MARKER%" "%HOSTS%" >nul 2>&1
    if not errorlevel 1 (
        call :banner_fail "В hosts остались строки"
    ) else (
        call :banner_ok "Выключено"
    )
) else (
    call :line_fail "Нет доступа к hosts"
)
call :wait
goto :menu
:show
call :init_esc
call :header
call :section "Файл hosts"
set "found=0"
for /f "tokens=*" %%L in ('findstr /I "telegram" "%HOSTS%" 2^>nul') do (
    echo   !GRY!│!R!   !DIM!%%L!R!
    set "found=1"
)
if "!found!"=="0" (
    call :line_info "Строк Telegram в hosts пока нет"
    call :line_info "Так бывает, если fix еще не включали"
    call :line_info "Сначала [4] Поиск IP, затем [1] Включить"
)
call :wait
goto :menu
:bye
call :header
echo     !GRY!Пока.!R!
echo.
timeout /t 1 >nul
exit /b 0
