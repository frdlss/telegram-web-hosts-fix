# Переключить шрифт ТЕКУЩЕГО окна на TrueType + записать дефолт в реестр.
# Для conhost важны HKCU\Console и подключ для пути к cmd.exe (см. MSDN про Console registry).
# ForceV2=1 отключает legacy-консоль; иногда нужен один раз закрыть все окна cmd и открыть снова.
# Вызывать из cmd в ЭТОМ же окне (без -WindowStyle Hidden).

$ErrorActionPreference = 'Stop'

function Get-CmdExeConsoleRegPath {
    $exe = Join-Path $env:SystemRoot 'System32\cmd.exe'
    if ($exe.Length -lt 4) { return $null }
    # C:\Windows\System32\cmd.exe -> C:_Windows_System32_cmd.exe
    $tail = $exe.Substring(3).Replace('\', '_')
    return $exe[0] + ':_' + $tail
}

function Apply-ConsoleRegistryFont {
    param(
        [Parameter(Mandatory)][string]$Face,
        [Parameter(Mandatory)][string]$RegPath
    )
    if (-not (Test-Path -LiteralPath $RegPath)) {
        New-Item -Path $RegPath -Force | Out-Null
    }
    Set-ItemProperty -LiteralPath $RegPath -Name 'FaceName' -Value $Face -Type String -Force -ErrorAction SilentlyContinue
    Set-ItemProperty -LiteralPath $RegPath -Name 'FontFamily' -Value 54 -Type DWord -Force -ErrorAction SilentlyContinue
    Set-ItemProperty -LiteralPath $RegPath -Name 'FontWeight' -Value 400 -Type DWord -Force -ErrorAction SilentlyContinue
    Set-ItemProperty -LiteralPath $RegPath -Name 'FontSize' -Value 0x00140000 -Type DWord -Force -ErrorAction SilentlyContinue
}

function Apply-ConsoleWindowGeometry {
    param([Parameter(Mandatory)][string]$RegPath)
    if (-not (Test-Path -LiteralPath $RegPath)) {
        New-Item -Path $RegPath -Force | Out-Null
    }
    $cols = 100
    $rows = 40
    $bufH = 3000
    # Низкое слово — ширина, высокое — высота (символы). См. документацию по ключам реестра консоли.
    $win = ($rows -shl 16) -bor ($cols -band 0xFFFF)
    $buf = ($bufH -shl 16) -bor ($cols -band 0xFFFF)
    Set-ItemProperty -LiteralPath $RegPath -Name 'WindowSize' -Value $win -Type DWord -Force -ErrorAction SilentlyContinue
    Set-ItemProperty -LiteralPath $RegPath -Name 'ScreenBufferSize' -Value $buf -Type DWord -Force -ErrorAction SilentlyContinue
}

# Отключает «старую» консоль, иначе API/реестр часто не переключают TTF.
$root = 'HKCU:\Console'
if (-not (Test-Path -LiteralPath $root)) {
    New-Item -Path $root -Force | Out-Null
}
Set-ItemProperty -LiteralPath $root -Name 'ForceV2' -Value 1 -Type DWord -Force -ErrorAction SilentlyContinue

$cmdSub = Get-CmdExeConsoleRegPath
$regTargets = @($root)
if ($cmdSub) {
    $regTargets += (Join-Path $root $cmdSub)
}

Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;

public static class ConsoleTtf {
    public const int STD_OUTPUT_HANDLE = -11;

    [DllImport("kernel32.dll", SetLastError = true)]
    public static extern IntPtr GetStdHandle(int nStdHandle);

    [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    public static extern bool GetCurrentConsoleFontEx(IntPtr hConsoleOutput, bool bMaximumWindow, ref CONSOLE_FONT_INFOEX lpConsoleCurrentFontEx);

    [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    public static extern bool SetCurrentConsoleFontEx(IntPtr hConsoleOutput, bool bMaximumWindow, ref CONSOLE_FONT_INFOEX lpConsoleCurrentFontEx);

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    public struct CONSOLE_FONT_INFOEX {
        public uint cbSize;
        public uint nFont;
        public short dwFontSizeX;
        public short dwFontSizeY;
        public uint FontFamily;
        public uint FontWeight;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)]
        public string FaceName;
    }
}
'@ -ErrorAction Stop

$h = [ConsoleTtf]::GetStdHandle([ConsoleTtf]::STD_OUTPUT_HANDLE)
if ($h -eq [IntPtr]::Zero -or $h -eq [IntPtr]::new(-1)) { exit 0 }

$size = [uint32][Runtime.InteropServices.Marshal]::SizeOf([Type][ConsoleTtf+CONSOLE_FONT_INFOEX])

function Normalize-Face([string]$s) {
    if ([string]::IsNullOrEmpty($s)) { return '' }
    $i = $s.IndexOf([char]0)
    if ($i -ge 0) { $s = $s.Substring(0, $i) }
    return $s.Trim()
}

function Test-FontApplied {
    param([string]$ExpectedFace, [bool]$MaxWin)
    $v = [ConsoleTtf+CONSOLE_FONT_INFOEX]::new()
    $v.cbSize = $size
    if (-not [ConsoleTtf]::GetCurrentConsoleFontEx($h, $MaxWin, [ref]$v)) { return $false }
    return ((Normalize-Face $v.FaceName) -eq $ExpectedFace)
}

function Try-SetFace {
    param([string]$face, [int]$fontY)
    foreach ($reg in $regTargets) {
        try {
            Apply-ConsoleRegistryFont -Face $face -RegPath $reg
            Apply-ConsoleWindowGeometry -RegPath $reg
        } catch { }
    }

    $t = [ConsoleTtf+CONSOLE_FONT_INFOEX]::new()
    $t.cbSize = $size
    if (-not [ConsoleTtf]::GetCurrentConsoleFontEx($h, $false, [ref]$t)) { return $false }
    if ((Normalize-Face $t.FaceName) -eq $face) { return $true }

    $t.FaceName = $face
    $t.nFont = 0
    $t.dwFontSizeX = 0
    $t.dwFontSizeY = [int16]$fontY
    $t.FontFamily = 54
    $t.FontWeight = 400

    foreach ($max in @($false, $true)) {
        if ([ConsoleTtf]::SetCurrentConsoleFontEx($h, $max, [ref]$t)) {
            if (Test-FontApplied -ExpectedFace $face -MaxWin $max) { return $true }
            if (Test-FontApplied -ExpectedFace $face -MaxWin $false) { return $true }
        }
    }
    return $false
}

# Порядок: системные шрифты, которые чаще всего есть; два размера — часть сборок отклоняет 20.
$faces = @(
    @{ N = 'Consolas'; Y = 20 },
    @{ N = 'Consolas'; Y = 18 },
    @{ N = 'Lucida Console'; Y = 20 },
    @{ N = 'Lucida Console'; Y = 16 },
    @{ N = 'Cascadia Mono'; Y = 20 },
    @{ N = 'Cascadia Mono'; Y = 18 },
    @{ N = 'Segoe UI Mono'; Y = 20 }
)

foreach ($item in $faces) {
    if (Try-SetFace -face $item.N -fontY $item.Y) { exit 0 }
}

exit 0
