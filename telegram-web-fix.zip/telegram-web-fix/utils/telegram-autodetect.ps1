﻿# Auto-detect reachable Telegram DC IP, port 443 (console output via .bat)
param(
    [Parameter(Mandatory = $true)]
    [string]$LogFile
)

$ErrorActionPreference = 'SilentlyContinue'
$ProgressPreference = 'SilentlyContinue'

$Root = Split-Path -Parent $PSScriptRoot
if (-not $Root) { $Root = (Get-Location).Path }

$CfgFile = Join-Path $Root 'telegram-web-ip.cfg'
$ListFile = Join-Path $Root 'lists\telegram-ip-candidates.txt'

function Emit([string]$Code, [string]$Arg1 = '', [string]$Arg2 = '') {
    $line = if ($Arg2) { "$Code|$Arg1|$Arg2" } elseif ($Arg1) { "$Code|$Arg1" } else { $Code }
    Add-Content -LiteralPath $LogFile -Value $line -Encoding ASCII
}

function Test-Tcp443 {
    param(
        [Parameter(Mandatory)][string]$HostName,
        [int]$TimeoutMs = 2500
    )
    $client = [System.Net.Sockets.TcpClient]::new()
    try {
        $iar = $client.BeginConnect($HostName, 443, $null, $null)
        if (-not $iar.AsyncWaitHandle.WaitOne($TimeoutMs, $false)) {
            return $false
        }
        $client.EndConnect($iar)
        return $client.Connected
    } catch {
        return $false
    } finally {
        if ($client.Connected) { $client.Close() }
        $client.Dispose()
    }
}

if (Test-Path -LiteralPath $LogFile) {
    Remove-Item -LiteralPath $LogFile -Force
}

$dnsIp = $null
try {
    $dns = Resolve-DnsName -Name 'web.telegram.org' -Server '1.1.1.1' -Type A -DnsOnly -ErrorAction Stop
    $dnsIp = ($dns | Where-Object { $_.IPAddress -match '^\d+\.' } | Select-Object -First 1).IPAddress
} catch {}

if ($dnsIp) {
    Emit 'DNS' $dnsIp
} else {
    Emit 'NODNS'
}

$candidates = @()
if (Test-Path -LiteralPath $ListFile) {
    $candidates = Get-Content -LiteralPath $ListFile |
        ForEach-Object { $_.Trim() } |
        Where-Object { $_ -match '^\d{1,3}(\.\d{1,3}){3}$' }
}

if ($dnsIp -and ($candidates -notcontains $dnsIp)) {
    $candidates = @($dnsIp) + $candidates
}

$candidates = $candidates | Select-Object -Unique
if (-not $candidates) {
    Emit 'ERR' 'empty_list'
    exit 1
}

Emit 'COUNT' ([string]$candidates.Count)

$found = $null
foreach ($ip in $candidates) {
    if ($ip -eq $dnsIp) {
        Emit 'ROW' $ip 'skip'
        continue
    }
    if (Test-Tcp443 -HostName $ip) {
        Emit 'ROW' $ip 'ok'
        $found = $ip
        break
    }
    Emit 'ROW' $ip 'fail'
}

if (-not $found) {
    Emit 'ERR' 'no_reply'
    exit 1
}

$utf8NoBom = [System.Text.UTF8Encoding]::new($false)
[System.IO.File]::WriteAllText($CfgFile, "$found`r`n", $utf8NoBom)
Emit 'FOUND' $found
exit 0
