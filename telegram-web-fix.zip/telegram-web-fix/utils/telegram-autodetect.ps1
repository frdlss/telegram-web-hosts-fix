﻿# Auto-detect reachable Telegram DC IP, port 443 (log for telegram-web-fix.bat)
param(
    [Parameter(Mandatory = $true)]
    [string]$LogFile,

    [Parameter(Mandatory = $false)]
    [int]$Parallel = -1
)

$ErrorActionPreference = 'SilentlyContinue'
$ProgressPreference = 'SilentlyContinue'
$WarningPreference = 'SilentlyContinue'

$Root = Split-Path -Parent $PSScriptRoot
if (-not $Root) { $Root = (Get-Location).Path }

$CfgFile = Join-Path $Root 'telegram-web-ip.cfg'
$ListFile = Join-Path $Root 'lists\telegram-ip-candidates.txt'
$DomainsFile = Join-Path $Root 'lists\telegram-hosts-domains.txt'

$VerboseLog = ($env:TG_SCAN_VERBOSE_LOG -eq '1')
if ($Parallel -lt 1 -or $Parallel -gt 32) {
    $pEnv = 0
    if ([int]::TryParse($env:TG_SCAN_PARALLEL, [ref]$pEnv) -and $pEnv -ge 1 -and $pEnv -le 32) {
        $Parallel = $pEnv
    } else {
        $Parallel = 20
    }
}

$EnablePass2 = ($env:TG_SCAN_PASS2 -eq '1')

$script:LogUtf8 = [System.Text.UTF8Encoding]::new($false)

function Emit([string]$Code, [string]$Arg1 = '', [string]$Arg2 = '') {
    $line = if ($Arg2) { "$Code|$Arg1|$Arg2" } elseif ($Arg1) { "$Code|$Arg1" } else { $Code }
    [System.IO.File]::AppendAllText($LogFile, $line + [Environment]::NewLine, $script:LogUtf8)
}

function Write-VerboseLine([string]$Message) {
    if (-not $VerboseLog) { return }
    $t = $Message
    if ($null -eq $t) { return }
    $t = $t.TrimEnd()
    if ($t.Length -eq 0) { return }
    Emit 'MSG' $t
}

function Test-WaveTcp443 {
    param(
        [Parameter(Mandatory)][string[]]$Ips,
        [Parameter(Mandatory)][int]$TimeoutMs
    )
    if (-not $Ips -or $Ips.Count -eq 0) { return $null }

    $items = @(
        foreach ($ip in $Ips) {
            $c = [System.Net.Sockets.TcpClient]::new()
            try {
                $iar = $c.BeginConnect($ip, 443, $null, $null)
                [PSCustomObject]@{ Client = $c; Iar = $iar; Ip = $ip; Handled = $false }
            } catch {
                try { $c.Dispose() } catch {}
                $null
            }
        }
    ) | Where-Object { $_ }

    if (-not $items) { return $null }

    $deadline = [Environment]::TickCount64 + $TimeoutMs
    $winner = $null
    while ([Environment]::TickCount64 -lt $deadline -and -not $winner) {
        $stillPending = $false
        foreach ($s in $items) {
            if ($s.Handled) { continue }
            if (-not $s.Iar.IsCompleted) {
                $stillPending = $true
                continue
            }
            $s.Handled = $true
            try {
                $s.Client.EndConnect($s.Iar)
                if ($s.Client.Connected) { $winner = $s.Ip }
            } catch {}
        }
        if ($winner) { break }
        if (-not $stillPending) { break }
        Start-Sleep -Milliseconds 20
    }

    foreach ($s in $items) {
        try {
            if ($s.Client.Connected) { $s.Client.Close() }
        } catch {}
        try { $s.Client.Dispose() } catch {}
    }

    return $winner
}

function Test-Tnc443 {
    param([Parameter(Mandatory)][string]$Ip)
    try {
        $r = Test-NetConnection -ComputerName $Ip -Port 443 -WarningAction SilentlyContinue
        return ($r -and $r.TcpTestSucceeded)
    } catch {
        return $false
    }
}

function Add-Ipv4ToSet([System.Collections.Generic.HashSet[string]]$Set, [string]$Ip) {
    if ($Ip -and $Ip -match '^\d{1,3}(\.\d{1,3}){3}$') {
        [void]$Set.Add($Ip.Trim())
    }
}

function Resolve-NameA([string]$Name) {
    $ips = New-Object 'System.Collections.Generic.HashSet[string]'
    try {
        $addrs = [System.Net.Dns]::GetHostAddresses($Name)
        foreach ($a in $addrs) {
            if ($a.AddressFamily -eq [System.Net.Sockets.AddressFamily]::InterNetwork) {
                [void]$ips.Add($a.ToString())
            }
        }
    } catch {}
    return @($ips)
}

function Add-IpsToCandidateFile([string[]]$Ips) {
    if (-not $Ips -or $Ips.Count -eq 0) { return }
    if (-not (Test-Path -LiteralPath $ListFile)) { return }
    $header = [System.Collections.ArrayList]@()
    $existing = [System.Collections.ArrayList]@()
    foreach ($line in (Get-Content -LiteralPath $ListFile)) {
        $t = $line.Trim()
        if ($t -match '^\d{1,3}(\.\d{1,3}){3}$') {
            [void]$existing.Add($t)
        } elseif ($t) {
            [void]$header.Add($line)
        }
    }
    $seen = @{}
    foreach ($e in $existing) { $seen[$e] = $true }
    $prepend = [System.Collections.ArrayList]@()
    foreach ($ip in $Ips) {
        $ip = $ip.Trim()
        if ($ip -match '^\d{1,3}(\.\d{1,3}){3}$' -and -not $seen.ContainsKey($ip)) {
            [void]$prepend.Add($ip)
            $seen[$ip] = $true
        }
    }
    if ($prepend.Count -eq 0) { return }
    $out = @($header) + @($prepend) + @($existing)
    [System.IO.File]::WriteAllLines($ListFile, $out, $script:LogUtf8)
    Emit 'ADDED' ([string]$prepend.Count)
}

if (Test-Path -LiteralPath $LogFile) {
    Remove-Item -LiteralPath $LogFile -Force
}

$dnsServerList = @('1.1.1.1', '1.0.0.1', '8.8.8.8', '9.9.9.9')
$dnsJobs = @()
for ($ji = 0; $ji -lt $dnsServerList.Count; $ji++) {
    $srvOne = $dnsServerList[$ji]
    $dnsJobs += Start-Job -Name ("tgDns{0}" -f $ji) -ScriptBlock {
        param($QueryName, $Srv)
        try {
            Resolve-DnsName -Name $QueryName -Server $Srv -Type A -DnsOnly -ErrorAction Stop
        } catch {
            $null
        }
    } -ArgumentList 'web.telegram.org', $srvOne
}

$null = Wait-Job -Job $dnsJobs -Timeout 3
foreach ($j in $dnsJobs) {
    if ($j.State -eq 'Running') {
        Stop-Job -Job $j -ErrorAction SilentlyContinue
    }
}

$dnsSet = New-Object 'System.Collections.Generic.HashSet[string]'
$dnsFirst = $null
$dnsServersOk = 0

for ($ji = 0; $ji -lt $dnsServerList.Count; $ji++) {
    $srv = $dnsServerList[$ji]
    $j = Get-Job -Name ("tgDns{0}" -f $ji) -ErrorAction SilentlyContinue
    $dnsOut = $null
    if ($j -and $j.State -eq 'Completed') {
        try {
            $dnsOut = Receive-Job -Job $j -ErrorAction SilentlyContinue
        } catch { }
    }
    $anyA = $false
    if ($dnsOut) {
        foreach ($r in ($dnsOut | Where-Object { $_.IPAddress -match '^\d+\.' })) {
            $anyA = $true
            Add-Ipv4ToSet $dnsSet $r.IPAddress
            if (-not $dnsFirst) { $dnsFirst = $r.IPAddress.Trim() }
        }
    }
    if ($anyA) { $dnsServersOk++ }
    $st = if ($anyA) { 'ok' } elseif ($j -and $j.State -eq 'Completed') { 'empty' } else { 'timeout' }
    Emit 'DR' $srv $st
    if ($j) {
        Remove-Job -Job $j -Force -ErrorAction SilentlyContinue
    }
}

if ($dnsFirst) {
    Emit 'DNS' $dnsFirst
    Emit 'DS' 'web.telegram.org' $dnsFirst
} else {
    Emit 'NODNS'
    Emit 'DS' 'web.telegram.org' '-'
}

$extraResolve = @(
    'pluto.web.telegram.org',
    'kws2.web.telegram.org',
    'zws2.web.telegram.org',
    'venus.web.telegram.org'
)
if (Test-Path -LiteralPath $DomainsFile) {
    $fromFile = @(Get-Content -LiteralPath $DomainsFile |
        ForEach-Object { $_.Trim() } |
        Where-Object { $_ -and $_ -notmatch '^\s*#' -and $_ -match '\.' })
    foreach ($d in $fromFile) {
        if ($extraResolve -notcontains $d) {
            $extraResolve += $d
        }
    }
}
$extraResolve = @($extraResolve | Select-Object -Unique)
$dsShown = 0
$dsMaxShow = 5
foreach ($name in $extraResolve) {
    if ($name -eq 'web.telegram.org') { continue }
    $addrs = Resolve-NameA $name
    if ($addrs.Count -gt 0) {
        foreach ($a in $addrs) {
            Add-Ipv4ToSet $dnsSet $a
        }
        if ($dsShown -lt $dsMaxShow) {
            Emit 'DS' $name ($addrs[0])
            $dsShown++
        }
    } elseif ($dsShown -lt $dsMaxShow) {
        Emit 'DS' $name '-'
        $dsShown++
    }
}
$dsHidden = ($extraResolve.Count - 1) - $dsShown
if ($dsHidden -gt 0) {
    Emit 'DSN' ([string]$dsHidden)
}

$fileList = @()
if (Test-Path -LiteralPath $ListFile) {
    $fileList = @(Get-Content -LiteralPath $ListFile |
        ForEach-Object { $_.Trim() } |
        Where-Object { $_ -match '^\d{1,3}(\.\d{1,3}){3}$' })
}

$queue = New-Object System.Collections.ArrayList
foreach ($ip in $fileList) {
    if (-not $dnsSet.Contains($ip)) { [void]$queue.Add($ip) }
}
foreach ($ip in $fileList) {
    if ($dnsSet.Contains($ip)) { [void]$queue.Add($ip) }
}
foreach ($ip in $dnsSet) {
    if ($fileList -notcontains $ip) { [void]$queue.Add($ip) }
}

$seen = @{}
$candidates = @(
    foreach ($ip in $queue) {
        if ($seen.ContainsKey($ip)) { continue }
        $seen[$ip] = $true
        $ip
    }
)

if (-not $candidates) {
    Emit 'ERR' 'empty_list'
    exit 1
}

$TcpTimeoutMs = 3200
if ($candidates.Count -gt 400) { $TcpTimeoutMs = 1600 }
elseif ($candidates.Count -gt 250) { $TcpTimeoutMs = 1800 }
elseif ($candidates.Count -gt 120) { $TcpTimeoutMs = 2200 }

Emit 'COUNT' ([string]$candidates.Count)
Emit 'Q' ([string]$candidates.Count) ([string]$Parallel)
Emit 'MS' ([string]$TcpTimeoutMs)

$found = $null
$tcpProbed = 0
$total = $candidates.Count
$idx = 0

while ($idx -lt $total -and -not $found) {
    $waveSize = [Math]::Min($Parallel, $total - $idx)
    $wave = @($candidates[$idx..($idx + $waveSize - 1)])
    $idx += $waveSize
    $tcpProbed += $wave.Count

    $toN = $idx
    Emit 'PROG' ([string]$toN) ([string]$total)
    Write-VerboseLine ("  [{0}/{1}] TCP :443 — {2}" -f $toN, $total, ($wave -join ', '))

    $hit = Test-WaveTcp443 -Ips $wave -TimeoutMs $TcpTimeoutMs
    if ($hit) {
        $found = $hit
        Emit 'LIVE' 'ok' $hit
        Emit 'ROW' $hit 'ok'
        if ($VerboseLog) {
            foreach ($ip in $wave) {
                if ($ip -ne $hit) { Emit 'ROW' $ip 'fail' }
            }
        }
        break
    }
    if ($VerboseLog) {
        foreach ($ip in $wave) {
            Emit 'ROW' $ip 'fail'
        }
    }
}

$ranPass2 = $false
$tncProbed = 0

if (-not $found -and $EnablePass2) {
    Emit 'PASS2' 'tnc'
    $ranPass2 = $true
    $pass2Max = [Math]::Min(48, $candidates.Count)
    $i = 0
    foreach ($ip in ($candidates | Select-Object -First $pass2Max)) {
        $i++
        Emit 'PROG' ([string]$i) ([string]$total)
        Write-VerboseLine ("  [фаза 2] [{0}/{1}] {2}" -f $i, $total, $ip)
        $tncProbed++
        if (Test-Tnc443 -Ip $ip) {
            Emit 'LIVE' 'ok2' $ip
            Emit 'ROW' $ip 'ok2'
            $found = $ip
            break
        }
        if ($VerboseLog) { Emit 'ROW' $ip 'fail2' }
    }
}

if (-not $found) {
    Emit 'N' 'diag' '1'
    Emit 'N' 'cand' ([string]$candidates.Count)
    Emit 'N' 'file' ([string]$fileList.Count)
    Emit 'N' 'dnsA' ([string]$dnsSet.Count)
    Emit 'N' 'dnsSrv' ([string]$dnsServersOk)
    Emit 'N' 'tcpTry' ([string]$tcpProbed)
    Emit 'N' 'tncTry' ([string]$tncProbed)
    Emit 'N' 'ms' ([string]$TcpTimeoutMs)
    Emit 'N' 'parallel' ([string]$Parallel)
    Emit 'N' 'pass2' $(if ($ranPass2) { '1' } else { '0' })
    Emit 'ERR' 'no_reply'
    Emit 'DONE' '1'
    exit 1
}

$utf8NoBom = [System.Text.UTF8Encoding]::new($false)
[System.IO.File]::WriteAllText($CfgFile, "$found`r`n", $utf8NoBom)
$toAdd = @($found) + @($dnsSet)
Add-IpsToCandidateFile $toAdd
Emit 'FOUND' $found
Emit 'DONE' '0'
exit 0
